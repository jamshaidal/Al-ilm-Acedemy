# 🔐 Admin Login Credentials

## Current Credentials ✅

**Email**: `jamshaid8081@gmail.com`  
**Password**: `SecurePass@123`

---

## ✅ Verification

Backend login endpoint tested and working:
```
POST http://localhost:5000/api/auth/login
```

**Response**: Token generated successfully ✅

---

## 🎯 How to Login

1. Open http://localhost:5174
2. Click "Admin Login" button (or go directly to `/login`)
3. Enter email: `jamshaid8081@gmail.com`
4. Enter password: `SecurePass@123`
5. Click "Login"
6. You'll be redirected to `/admin` dashboard

---

## 🐛 If Login Still Fails

### Check 1: Verify Backend is Running
```bash
# Should show port 5000 listening
netstat -ano | findstr "5000"
```

### Check 2: Test Backend Directly
```bash
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"jamshaid8081@gmail.com","password":"SecurePass@123"}'
```

### Check 3: Check Browser Console
- Open DevTools (F12)
- Go to Console tab
- Try logging in again
- Look for error messages

### Check 4: Check Network Tab
- F12 → Network tab
- Try login
- Look for `/api/auth/login` request
- Check response status and body

---

## ⚠️ Common Issues

### "Invalid credentials"
- Double-check email is exactly: `jamshaid8081@gmail.com`
- Verify password is exactly: `SecurePass@123`
- Make sure MongoDB is running
- Check backend is running on port 5000

### Network Error / Cannot reach server
- Backend not running on port 5000
- Firewall blocking port 5000
- Check terminal for backend errors

### Token not saving
- Check browser allows localStorage
- Check for CORS errors in console
- Verify API_URL in frontend config

---

## 📝 Important Notes

- Password is case-sensitive
- Email is case-insensitive (converted to lowercase)
- Token expires in 12 hours
- Token stored in localStorage

---

## 🔧 To Change Password in Future

Run this command:
```bash
cd notes-backend
node scripts/reset-admin-password.js jamshaid8081@gmail.com "YourNewPassword"
```

Then update `.env` file with the new password.
