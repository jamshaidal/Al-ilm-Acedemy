# 🔑 CREDENTIALS & QUICK START

## Admin Login
```
Email: jamshaid8081@gmail.com
Password: SecurePass@123
```

✅ **Tested - Works!**

---

## Access URLs

| URL | Purpose |
|-----|---------|
| http://localhost:5174 | **Main Website** |
| http://localhost:5000 | Backend API |
| http://localhost:5000/api/notes | View all notes |
| http://localhost:5000/api/health | Check backend |

---

## Current Notes

✅ Physics Chapter 1 (Class 9)  
✅ Chemistry Notes (Class 9)  
✅ Math Chapter 5 (Class 10)  

---

## Start Services

**Terminal 1 - Backend:**
```bash
cd notes-backend
node index.js
```

**Terminal 2 - Frontend:**
```bash
cd my-notes-site
npm run dev
```

---

## Test Steps

1. Open http://localhost:5174
2. Click "Login"
3. Use credentials above
4. Dashboard opens ✅
5. Go back to home
6. Pick Class 9 → Physics
7. Click "View / Download"
8. PDF opens ✅

---

## Everything Working ✅

📚 Notes visible  
🔐 Login working  
📥 Upload ready  
📄 PDFs downloadable  
🌙 Dark mode on  
📱 Mobile friendly  

**Ready to go!** 🚀
