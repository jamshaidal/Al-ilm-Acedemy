#!/usr/bin/env node

/**
 * PDF Worker Verification Script
 * Tests if the PDF worker can be loaded correctly
 */

const https = require('https');

const workerUrls = [
  'https://unpkg.com/pdfjs-dist@4.11.0/build/pdf.worker.min.js',
  'https://unpkg.com/pdfjs-dist@3.11.174/build/pdf.worker.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js',
];

console.log('🔍 Testing PDF Worker URLs...\n');

Promise.all(
  workerUrls.map(
    url =>
      new Promise((resolve) => {
        https
          .head(url, (res) => {
            const status = res.statusCode;
            const ok = status === 200;
            console.log(`${ok ? '✅' : '❌'} ${url}`);
            console.log(`   Status: ${status}\n`);
            resolve(ok);
          })
          .on('error', (e) => {
            console.log(`❌ ${url}`);
            console.log(`   Error: ${e.message}\n`);
            resolve(false);
          });
      })
  )
).then((results) => {
  const working = results.filter(Boolean).length;
  console.log(`\n📊 Results: ${working}/${results.length} URLs are accessible`);
  process.exit(working > 0 ? 0 : 1);
});
