# 🔐 Admin Login - Complete Troubleshooting Guide

## ✅ Correct Login Credentials

| Field | Value |
|-------|-------|
| **Email** | `jamshaid8081@gmail.com` |
| **Password** | `SecurePass@123` |

⚠️ **Important**: The old password `hassan@03` no longer works. Use the new password above.

---

## 🔍 Step-by-Step Troubleshooting

### Step 1: Verify Backend is Running
```powershell
# Check if port 5000 is listening
netstat -ano | findstr "5000"
```

You should see:
```
TCP    0.0.0.0:5000           0.0.0.0:0           LISTENING       [PID]
```

If NOT running, start it:
```bash
cd notes-backend
node index.js
```

### Step 2: Test Login Endpoint Directly
```powershell
$body = @{
    email = "jamshaid8081@gmail.com"
    password = "SecurePass@123"
} | ConvertTo-Json

Invoke-WebRequest -Uri "http://localhost:5000/api/auth/login" `
  -Method POST `
  -ContentType "application/json" `
  -Body $body
```

**Expected Response**: A JSON token object
```json
{"token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."}
```

**If you get "Invalid credentials"**: 
- Password doesn't match database
- Run reset script again (see below)

### Step 3: Check Browser Console
1. Open http://localhost:5174
2. Press `F12` (DevTools)
3. Click on "Login" button  
4. Look at Console tab for error messages
5. Should see: `Login attempt: { email: 'jamshaid8081@gmail.com', apiUrl: 'http://localhost:5000' }`

### Step 4: Check Network Tab
1. F12 → Network tab
2. Try logging in
3. Look for request to `/api/auth/login`
4. Check response status:
   - `200` = Success (has token)
   - `400` = Invalid credentials
   - `500` = Server error
   - `5XX` = Backend issues

### Step 5: Verify MongoDB
```powershell
# Check if MongoDB is running on port 27017
netstat -ano | findstr "27017"
```

Should see LISTENING status. If not, start MongoDB.

---

## 🚨 Common Error Messages

### "Invalid credentials"
**Cause**: Email or password is wrong
**Solution**:
1. Verify you're using: `jamshaid8081@gmail.com` and `SecurePass@123`
2. Check for extra spaces or typos
3. Run reset script:
```bash
cd notes-backend
node scripts/reset-admin-password.js jamshaid8081@gmail.com "SecurePass@123"
```

### "Cannot reach server"
**Cause**: Backend not running
**Solution**:
```bash
cd notes-backend
npm start
```

### "Server error"
**Cause**: Backend error (check server logs)
**Solution**:
1. Look at terminal where backend is running
2. Check for error messages
3. Verify MongoDB is connected
4. Restart backend

### "Network error" or "Failed to fetch"
**Cause**: CORS or connection issues
**Solution**:
1. Verify backend is on `http://localhost:5000`
2. Check browser console for CORS errors
3. Verify frontend API_URL is correct in `src/lib/api.ts`

---

## 🔧 How to Reset Password

If you forgot or need to change the password:

```bash
# Navigate to backend
cd notes-backend

# Reset with new password
node scripts/reset-admin-password.js jamshaid8081@gmail.com "YourNewPassword"

# Update .env file
# Edit notes-backend/.env and change:
# ADMIN_PASSWORD=YourNewPassword
```

---

## 📋 What to Include When Reporting Issues

If login still doesn't work after these steps, provide:

1. **Backend server logs** - copy output from terminal
2. **Browser console errors** - F12 → Console tab screenshot
3. **Network tab response** - F12 → Network tab → click login request
4. **What credentials you're using** - email & password attempt
5. **Error message** - exact text shown

---

## ✅ Login Flow Diagram

```
1. User enters email & password on LoginPage
   ↓
2. Frontend sends POST to /api/auth/login
   ↓
3. Backend validates:
   - Email matches ADMIN_EMAIL in .env
   - Password matches hashed password in database
   ↓
4. If valid: Return JWT token
   If invalid: Return "Invalid credentials"
   ↓
5. Frontend stores token in localStorage
   ↓
6. Frontend redirects to /admin dashboard
   ↓
7. Token sent with every API request (x-auth-token header)
```

---

## 🔐 Security Notes

- Password is hashed with bcryptjs (never stored in plain text)
- Token expires in 12 hours
- Email is case-insensitive (converted to lowercase)
- Password is case-sensitive
- Only the admin email can login

---

## ⚡ Quick Checklist

- [ ] Backend running on port 5000
- [ ] MongoDB connected
- [ ] Email is exactly: `jamshaid8081@gmail.com`
- [ ] Password is exactly: `SecurePass@123`
- [ ] No extra spaces in fields
- [ ] Browser console shows successful login
- [ ] Token appears in localStorage

If all above checks pass, login should work! ✅
