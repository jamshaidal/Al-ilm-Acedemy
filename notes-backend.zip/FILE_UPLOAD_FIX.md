# File Upload Naming - Fixed

## Problem
Files were being saved with timestamp prefix (e.g., `1763443472289-Profile.pdf`) instead of displaying the original filename (e.g., `Profile.pdf`)

## Solution
Modified the upload flow to preserve and store the original filename separately.

## Changes Made

### 1. Backend - Upload.js
Added `originalName` to the response:
```javascript
res.json({ 
  path: `/uploads/${req.file.filename}`,  // Used for actual file serving
  originalName: req.file.originalname     // Original filename for display
});
```

### 2. Backend - Note Model (Note.js)
Added `originalFileName` field to store the original filename:
```javascript
const noteSchema = new mongoose.Schema({
  title: String,
  classLevel: String,
  subject: String,
  filePath: String,
  originalFileName: String  // NEW: Stores original filename
});
```

### 3. Frontend - UploadNote.tsx
Updated to capture and send the original filename:
```typescript
const fileRes = await api.post('/api/upload', formData);
const filePath = fileRes.data.path;
const originalFileName = fileRes.data.originalName;  // NEW

await api.post('/api/notes', {
  title,
  classLevel,
  subject,
  filePath,
  originalFileName,  // NEW: Send to backend
});
```

## How It Works
1. User uploads `Profile.pdf`
2. Backend saves it as `1763443472289-Profile.pdf` (prevents name conflicts)
3. Backend returns both:
   - `path`: `/uploads/1763443472289-Profile.pdf` (for file serving)
   - `originalName`: `Profile.pdf` (for display)
4. Frontend stores `originalFileName` in the note
5. When displaying, the original filename is shown to users

## Files Updated
- ✅ `notes-backend/routes/Upload.js`
- ✅ `notes-backend/models/Note.js`
- ✅ `my-notes-site/src/components/UploadNote.tsx`

## Database Note
New uploads will have `originalFileName` field. Existing uploads may need migration if you want to populate this field retroactively (optional).
